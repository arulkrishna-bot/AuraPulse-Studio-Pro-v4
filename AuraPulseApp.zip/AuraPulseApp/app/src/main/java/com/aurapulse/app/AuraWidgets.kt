package com.aurapulse.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.widget.RemoteViews

/** Shared logic for all five AuraPulse home-screen widgets. */
object AuraWidgets {
    const val ACTION = "com.aurapulse.app.WIDGET_ACTION"
    private var lastKey = ""
    private var lastAt = 0L

    private val providers: List<Class<*>> = listOf(
        AuraWidget::class.java, AuraWidgetSquare::class.java, AuraWidgetCard::class.java,
        AuraWidgetMini::class.java, AuraWidgetQuick::class.java
    )

    fun refreshAll(c: Context) {
        try {
            val s = AuraMediaState
            val key = s.title + "|" + s.playing
            val now = System.currentTimeMillis()
            // the phone calls us about once a second while playing; only redraw that often for the progress bar
            if (key == lastKey && now - lastAt < 1500) return
            lastKey = key; lastAt = now
            val m = AppWidgetManager.getInstance(c)
            for (p in providers) {
                val ids = m.getAppWidgetIds(ComponentName(c, p))
                if (ids.isNotEmpty()) update(c, m, p, ids)
            }
        } catch (e: Exception) { }
    }

    fun update(c: Context, m: AppWidgetManager, p: Class<*>, ids: IntArray) {
        try {
            val v: RemoteViews = when (p) {
                AuraWidget::class.java -> bar(c)
                AuraWidgetSquare::class.java -> square(c)
                AuraWidgetCard::class.java -> card(c)
                AuraWidgetMini::class.java -> mini(c)
                else -> quick(c)
            }
            for (id in ids) m.updateAppWidget(id, v)
        } catch (e: Exception) { }
    }

    private fun alive(): Boolean = AuraMediaState.onAction != null && AuraMediaState.title.isNotEmpty()

    private fun launch(c: Context): PendingIntent {
        val i = c.packageManager.getLaunchIntentForPackage(c.packageName) ?: Intent()
        return PendingIntent.getActivity(c, 90, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun act(c: Context, code: Int, a: String): PendingIntent =
        if (!alive()) launch(c)
        else PendingIntent.getBroadcast(
            c, code,
            Intent(c, AuraWidget::class.java).setAction(ACTION).putExtra("aura_action", a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun rounded(src: Bitmap?, size: Int, radius: Float): Bitmap? {
        if (src == null) return null
        return try {
            val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val cv = Canvas(out)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            cv.drawRoundRect(RectF(0f, 0f, size.toFloat(), size.toFloat()), radius, radius, paint)
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            val side = minOf(src.width, src.height)
            val from = Rect((src.width - side) / 2, (src.height - side) / 2, (src.width + side) / 2, (src.height + side) / 2)
            cv.drawBitmap(src, from, Rect(0, 0, size, size), paint)
            out
        } catch (e: Exception) { null }
    }

    private fun cover(c: Context, v: RemoteViews, id: Int, sizeDp: Int, radiusDp: Float) {
        val d = c.resources.displayMetrics.density
        val px = (sizeDp * d).toInt().coerceIn(64, 420)
        val bm = rounded(AuraMediaState.art, px, radiusDp * d)
        if (bm != null) v.setImageViewBitmap(id, bm) else v.setImageViewResource(id, R.mipmap.ic_launcher)
    }

    private fun title(): String = if (AuraMediaState.title.isEmpty()) "AuraPulse" else AuraMediaState.title
    private fun artist(): String = if (AuraMediaState.title.isEmpty()) "Tap to open your music" else AuraMediaState.artist
    private fun playIcon(): Int = if (AuraMediaState.playing) R.drawable.ic_w_pause_w else R.drawable.ic_w_play_w
    private fun mmss(ms: Long): String { val t = (ms / 1000).coerceAtLeast(0); return (t / 60).toString() + ":" + (t % 60).toString().padStart(2, '0') }

    private fun playPause(c: Context, v: RemoteViews, id: Int, code: Int) {
        v.setImageViewResource(id, playIcon())
        v.setOnClickPendingIntent(id, act(c, code, if (AuraMediaState.playing) "pause" else "play"))
    }

    /* 1. Bar 4x1 */
    private fun bar(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.aura_widget)
        v.setTextViewText(R.id.w_title, title()); v.setTextViewText(R.id.w_artist, artist())
        cover(c, v, R.id.w_cover, 52, 14f)
        playPause(c, v, R.id.w_play, 92)
        v.setOnClickPendingIntent(R.id.w_root, launch(c))
        v.setOnClickPendingIntent(R.id.w_prev, act(c, 91, "prev"))
        v.setOnClickPendingIntent(R.id.w_next, act(c, 93, "next"))
        return v
    }

    /* 2. Square cover 2x2 */
    private fun square(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.aura_widget_square)
        v.setTextViewText(R.id.w_title, title()); v.setTextViewText(R.id.w_artist, artist())
        cover(c, v, R.id.w_cover, 150, 22f)
        playPause(c, v, R.id.w_play, 102)
        v.setOnClickPendingIntent(R.id.w_root, launch(c))
        return v
    }

    /* 3. Player card 4x2 with progress */
    private fun card(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.aura_widget_card)
        val s = AuraMediaState
        v.setTextViewText(R.id.w_title, title()); v.setTextViewText(R.id.w_artist, artist())
        cover(c, v, R.id.w_cover, 92, 18f)
        playPause(c, v, R.id.w_play, 112)
        val pct = if (s.dur > 0) ((s.pos * 1000) / s.dur).toInt().coerceIn(0, 1000) else 0
        v.setProgressBar(R.id.w_progress, 1000, pct, false)
        v.setTextViewText(R.id.w_pos, mmss(s.pos)); v.setTextViewText(R.id.w_dur, mmss(s.dur))
        v.setOnClickPendingIntent(R.id.w_root, launch(c))
        v.setOnClickPendingIntent(R.id.w_prev, act(c, 111, "prev"))
        v.setOnClickPendingIntent(R.id.w_next, act(c, 113, "next"))
        v.setOnClickPendingIntent(R.id.w_shuffle, act(c, 114, "shuffle"))
        v.setOnClickPendingIntent(R.id.w_fav, act(c, 115, "fav"))
        return v
    }

    /* 4. Mini 2x1 */
    private fun mini(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.aura_widget_mini)
        cover(c, v, R.id.w_cover, 46, 23f)
        playPause(c, v, R.id.w_play, 122)
        v.setOnClickPendingIntent(R.id.w_root, launch(c))
        v.setOnClickPendingIntent(R.id.w_next, act(c, 123, "next"))
        return v
    }

    /* 5. Quick actions 4x1 */
    private fun quick(c: Context): RemoteViews {
        val v = RemoteViews(c.packageName, R.layout.aura_widget_quick)
        playPause(c, v, R.id.q_play, 132)
        v.setOnClickPendingIntent(R.id.w_root, launch(c))
        v.setOnClickPendingIntent(R.id.q_open, launch(c))
        v.setOnClickPendingIntent(R.id.q_shuffle, act(c, 133, "shuffle"))
        v.setOnClickPendingIntent(R.id.q_fav, act(c, 134, "fav"))
        v.setOnClickPendingIntent(R.id.q_mute, act(c, 135, "mute"))
        return v
    }
}

/** 1. Bar (4x1). Also receives every widget button press. */
class AuraWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { AuraWidgets.update(c, m, AuraWidget::class.java, ids) }
    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val a = i.getStringExtra("aura_action")
        if (i.action == AuraWidgets.ACTION && a != null) AuraMediaState.onAction?.invoke(a)
    }
    companion object { fun refresh(c: Context) { AuraWidgets.refreshAll(c) } }
}

/** 2. Square cover (2x2). */
class AuraWidgetSquare : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { AuraWidgets.update(c, m, AuraWidgetSquare::class.java, ids) }
}

/** 3. Player card with progress (4x2). */
class AuraWidgetCard : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { AuraWidgets.update(c, m, AuraWidgetCard::class.java, ids) }
}

/** 4. Mini (2x1). */
class AuraWidgetMini : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { AuraWidgets.update(c, m, AuraWidgetMini::class.java, ids) }
}

/** 5. Quick actions (4x1). */
class AuraWidgetQuick : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { AuraWidgets.update(c, m, AuraWidgetQuick::class.java, ids) }
}
