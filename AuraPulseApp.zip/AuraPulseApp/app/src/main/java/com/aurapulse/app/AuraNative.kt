// AuraNative.kt — real lock-screen player for AuraPulse (WebView APK). NOT tested on a device.
// Package name: change to yours.
package com.aurapulse.app

import android.app.*
import android.content.*
import android.graphics.*
import android.os.*
import android.provider.Settings
import android.app.KeyguardManager
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import android.net.Uri
import androidx.core.app.ServiceCompat
import androidx.media.app.NotificationCompat.MediaStyle
import android.Manifest
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

object AuraMediaState {
    var title = ""; var artist = ""; var album = ""; var art: Bitmap? = null
    var playing = false; var pos = 0L; var dur = 0L
    var onAction: ((String) -> Unit)? = null   // set by MainActivity -> evaluateJavascript
}

object AuraMedia {
    // key ("m123" / "t5") -> content Uri. The page streams songs from here via /__media/<key>
    val uris = ConcurrentHashMap<String, Uri>()
}

class AuraBridge(private val act: Activity, private val web: WebView) {
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val ev: String = when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> "off"
                Intent.ACTION_SCREEN_ON -> "on"
                Intent.ACTION_USER_PRESENT -> "present"
                else -> ""
            }
            if (ev.isEmpty()) return
            act.runOnUiThread { web.evaluateJavascript("window.auraNativeScreen&&auraNativeScreen('" + ev + "')", null) }
        }
    }
    init {
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_SCREEN_ON)
        f.addAction(Intent.ACTION_USER_PRESENT)
        ContextCompat.registerReceiver(act, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }
    fun release() { try { act.unregisterReceiver(screenReceiver) } catch (e: Exception) { } }
    @JavascriptInterface fun openAppSettings() {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + act.packageName))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        act.startActivity(i)
    }
    @JavascriptInterface fun updateMedia(t: String, a: String, al: String, artB64: String, playing: Boolean, posMs: Long, durMs: Long) {
        val s = AuraMediaState
        s.title = t; s.artist = a; s.album = al; s.playing = playing; s.pos = posMs; s.dur = durMs
        if (artB64.isNotEmpty()) try { val b = Base64.decode(artB64, Base64.DEFAULT); s.art = BitmapFactory.decodeByteArray(b, 0, b.size) } catch (_: Exception) {}
        val i = Intent(act, AuraMediaService::class.java)
        if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i) else act.startService(i)
    }
    @JavascriptInterface fun isLocked(): Boolean = (act.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
    @JavascriptInterface fun setShowOnLock(on: Boolean) = act.runOnUiThread {
        if (Build.VERSION.SDK_INT >= 27) { act.setShowWhenLocked(on); act.setTurnScreenOn(on) }
        else {
            val f = android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            if (on) act.window.addFlags(f) else act.window.clearFlags(f)
        }
    }
    @JavascriptInterface fun requestUnlock() = act.runOnUiThread {
        if (Build.VERSION.SDK_INT >= 26) (act.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).requestDismissKeyguard(act, null)
    }
    @JavascriptInterface fun openCast() = act.startActivity(Intent(Settings.ACTION_CAST_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    @JavascriptInterface fun openBluetoothSettings() = act.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    @JavascriptInterface fun openOutputSwitcher() = act.startActivity(Intent("android.settings.panel.action.MEDIA_OUTPUT").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    @JavascriptInterface fun exitApp() = act.finishAffinity()

    private fun audioPerm(): String = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    @JavascriptInterface fun hasAudioPermission(): Boolean = act.checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED
    @JavascriptInterface fun requestAudioPermission() = act.runOnUiThread { act.requestPermissions(arrayOf(audioPerm()), 2) }
    @JavascriptInterface fun listDeviceAudio(): String {
        val arr = JSONArray()
        try {
            val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val cols = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.SIZE)
            val sel = MediaStore.Audio.Media.DURATION + " >= 20000 AND " + MediaStore.Audio.Media.IS_RINGTONE + " = 0 AND " +
                MediaStore.Audio.Media.IS_ALARM + " = 0 AND " + MediaStore.Audio.Media.IS_NOTIFICATION + " = 0"
            val c = act.contentResolver.query(base, cols, sel, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")
            if (c != null) {
                try {
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val key = "m" + id
                        AuraMedia.uris[key] = ContentUris.withAppendedId(base, id)
                        val artist = c.getString(3) ?: ""
                        val o = JSONObject()
                        o.put("key", key); o.put("name", c.getString(1) ?: "")
                        o.put("title", c.getString(2) ?: (c.getString(1) ?: "Song"))
                        o.put("artist", if (artist == "<unknown>") "" else artist)
                        o.put("album", c.getString(4) ?: ""); o.put("dur", c.getLong(5)); o.put("size", c.getLong(6))
                        arr.put(o)
                    }
                } finally { c.close() }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }
    @JavascriptInterface fun pickFolder() { (act as? MainActivity)?.startFolderForJs() }
    @JavascriptInterface fun shareText(t: String) = act.runOnUiThread {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t)
        act.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    @JavascriptInterface fun getLocalIp(): String {
        try {
            val en = java.net.NetworkInterface.getNetworkInterfaces()
            while (en.hasMoreElements()) {
                val ni = en.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val ad = ni.inetAddresses
                while (ad.hasMoreElements()) {
                    val a = ad.nextElement()
                    if (a is java.net.Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress) return a.hostAddress ?: ""
                }
            }
        } catch (e: Exception) { }
        return ""
    }

}

class AuraMediaService : Service() {
    private lateinit var session: MediaSessionCompat
    private val CH = "aura_media"
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CH, "Music playback", NotificationManager.IMPORTANCE_LOW).apply { lockscreenVisibility = Notification.VISIBILITY_PUBLIC })
        session = MediaSessionCompat(this, "AuraPulse").apply {
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { AuraMediaState.onAction?.invoke("play") }
                override fun onPause() { AuraMediaState.onAction?.invoke("pause") }
                override fun onSkipToNext() { AuraMediaState.onAction?.invoke("next") }
                override fun onSkipToPrevious() { AuraMediaState.onAction?.invoke("prev") }
                override fun onSeekTo(p: Long) { AuraMediaState.onAction?.invoke("seek:$p") }
            })
            isActive = true
        }
    }
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) { "play","pause","next","prev" -> { AuraMediaState.onAction?.invoke(i.action!!) } }
        val s = AuraMediaState
        session.setMetadata(MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, s.title).putString(MediaMetadataCompat.METADATA_KEY_ARTIST, s.artist)
            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, s.album).putLong(MediaMetadataCompat.METADATA_KEY_DURATION, s.dur)
            .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, s.art).build())
        session.setPlaybackState(PlaybackStateCompat.Builder()
            .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_SEEK_TO)
            .setState(if (s.playing) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED, s.pos, if (s.playing) 1f else 0f).build())
        fun pi(a: String, c: Int) = PendingIntent.getService(this, c, Intent(this, AuraMediaService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 0, packageManager.getLaunchIntentForPackage(packageName), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(s.title).setContentText(s.artist).setLargeIcon(s.art)
            .setContentIntent(open).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setOnlyAlertOnce(true).setOngoing(s.playing)
            .addAction(android.R.drawable.ic_media_previous, "Prev", pi("prev", 1))
            .addAction(if (s.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause", pi(if (s.playing) "pause" else "play", 2))
            .addAction(android.R.drawable.ic_media_next, "Next", pi("next", 3))
            .setStyle(MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2)).build()
        ServiceCompat.startForeground(this, 77, n, if (Build.VERSION.SDK_INT >= 29) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0)
        return START_NOT_STICKY
    }
    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { session.release(); super.onDestroy() }
}

/* ===== MainActivity: add these lines =====
   webView.settings.javaScriptEnabled = true
   webView.settings.mediaPlaybackRequiresUserGesture = false
   webView.addJavascriptInterface(AuraBridge(this, webView), "Android")
   AuraMediaState.onAction = { a -> runOnUiThread { webView.evaluateJavascript("window.auraNativeAction&&auraNativeAction('$a')", null) } }
   if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
   // Do NOT call webView.onPause() in onPause()/onStop() — it stops audio when the screen locks.
   // Keep android:hardwareAccelerated="true" on <application>.

   ===== AndroidManifest.xml =====
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
   <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
   <uses-permission android:name="android.permission.WAKE_LOCK"/>
   <service android:name=".AuraMediaService" android:exported="false" android:foregroundServiceType="mediaPlayback"/>
   (and on your <activity>: android:showWhenLocked="true" android:turnScreenOn="true" is optional; JS toggles it)

   ===== app/build.gradle =====
   implementation("androidx.media:media:1.7.0")
   implementation("androidx.core:core-ktx:1.13.1")
*/
