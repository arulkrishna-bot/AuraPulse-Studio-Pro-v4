package com.aurapulse.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val FILE_REQ = 41

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)

        // Serve assets over https://appassets.androidplatform.net so localStorage / IndexedDB keep a stable origin.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
        }
        web.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                filePathCb?.onReceiveValue(null); filePathCb = cb
                return try { startActivityForResult(p.createIntent(), FILE_REQ); true }
                catch (e: Exception) { filePathCb = null; false }
            }
        }
        web.addJavascriptInterface(AuraBridge(this, web), "Android")
        AuraMediaState.onAction = { a -> runOnUiThread { web.evaluateJavascript("window.auraNativeAction&&auraNativeAction('$a')", null) } }

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        // Phone back button -> the player's own back handling (it calls Android.exitApp() at the root).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { web.evaluateJavascript("(typeof handleAuraBack==='function')?handleAuraBack():null", null) }
        })

        if (b == null) web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    @Deprecated("file chooser result")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == FILE_REQ) { filePathCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data)); filePathCb = null }
        else super.onActivityResult(req, res, data)
    }
    // Intentionally NO web.onPause(): it would stop the music when the screen locks.
    override fun onDestroy() { AuraMediaState.onAction = null; super.onDestroy() }
}
