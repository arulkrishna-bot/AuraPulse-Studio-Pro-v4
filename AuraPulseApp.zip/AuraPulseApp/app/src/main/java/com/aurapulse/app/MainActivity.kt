package com.aurapulse.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val FILE_REQ = 41
    private val TREE_REQ = 42
    private var bridge: AuraBridge? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)

        // Serve assets over https://appassets.androidplatform.net so localStorage / IndexedDB keep a stable origin.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
        }
        web.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest) = loader.shouldInterceptRequest(r.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                filePathCb?.onReceiveValue(null)
                filePathCb = cb
                val types = p.acceptTypes.filter { it.isNotBlank() }
                val wantsAudio = types.any { it.startsWith("audio") }
                return try {
                    if (p.mode == 2) {
                        // Whole music folder: every song inside (and sub-folders) is added at once.
                        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), TREE_REQ)
                    } else if (wantsAudio) {
                        // Document picker: long-press or tick songs, then "Select all" to add many at once.
                        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                        i.addCategory(Intent.CATEGORY_OPENABLE)
                        i.type = "*/*"
                        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*"))
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        startActivityForResult(i, FILE_REQ)
                    } else {
                        startActivityForResult(p.createIntent(), FILE_REQ)
                    }
                    true
                } catch (e: Exception) {
                    filePathCb = null
                    false
                }
            }
        }
        bridge = AuraBridge(this, web)
        web.addJavascriptInterface(bridge!!, "Android")
        AuraMediaState.onAction = { a -> runOnUiThread { web.evaluateJavascript("window.auraNativeAction&&auraNativeAction('$a')", null) } }

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        // Phone back button -> the player's own back handling (it calls Android.exitApp() at the root).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { web.evaluateJavascript("(typeof handleAuraBack==='function')?handleAuraBack():null", null) }
        })

        if (b == null) web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    private fun isAudioName(name: String): Boolean {
        val n = name.lowercase()
        return n.endsWith(".mp3") || n.endsWith(".m4a") || n.endsWith(".aac") || n.endsWith(".flac") ||
            n.endsWith(".wav") || n.endsWith(".ogg") || n.endsWith(".opus") || n.endsWith(".wma") || n.endsWith(".amr")
    }

    private fun collectAudio(tree: Uri): Array<Uri> {
        val out = ArrayList<Uri>()
        fun walk(docId: String, depth: Int) {
            if (depth > 8) return
            val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
            )
            val c = contentResolver.query(kids, cols, null, null, null) ?: return
            val dirs = ArrayList<String>()
            try {
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val mime = c.getString(1) ?: ""
                    val name = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) dirs.add(id)
                    else if (mime.startsWith("audio/") || isAudioName(name)) out.add(DocumentsContract.buildDocumentUriUsingTree(tree, id))
                }
            } finally { c.close() }
            for (d in dirs) walk(d, depth + 1)
        }
        walk(DocumentsContract.getTreeDocumentId(tree), 0)
        return out.toTypedArray()
    }

    @Deprecated("file chooser result")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == FILE_REQ) {
            filePathCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            filePathCb = null
        } else if (req == TREE_REQ) {
            val cb = filePathCb
            filePathCb = null
            val tree = if (res == RESULT_OK) data?.data else null
            if (cb == null) return
            if (tree == null) { cb.onReceiveValue(null); return }
            Thread {
                val list: Array<Uri> = try { collectAudio(tree) } catch (e: Exception) { emptyArray() }
                runOnUiThread { cb.onReceiveValue(list) }
            }.start()
        } else {
            super.onActivityResult(req, res, data)
        }
    }

    // Intentionally NO web.onPause(): it would stop the music when the screen locks.
    override fun onDestroy() {
        AuraMediaState.onAction = null
        bridge?.release()
        super.onDestroy()
    }
}
