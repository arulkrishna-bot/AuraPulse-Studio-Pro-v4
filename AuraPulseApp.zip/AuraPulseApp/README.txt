AuraPulse – Android Studio project
1. Android Studio (Koala or newer) -> File > Open -> choose this folder. Let Gradle sync (needs internet once).
2. Run on your phone (USB debugging) or Build > Build APK(s).
3. To update the player later: replace app/src/main/assets/index.html with a new HTML file.
Package name: com.aurapulse.app (change in app/build.gradle.kts, AndroidManifest and the .kt files if you want).
