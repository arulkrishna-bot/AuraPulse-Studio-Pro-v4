package com.aurapulse.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.webkit.*
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import android.graphics.Color
import android.widget.FrameLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var filePathCb: ValueCallback<Array<Uri>>? = null
    private val FILE_REQ = 41
    private val TREE_REQ = 42
    private val TREE_JS_REQ = 43
    private var bridge: AuraBridge? = null
    lateinit var rootView: FrameLayout

    fun applyBars(hex: String, lightIcons: Boolean) {
        runOnUiThread {
            try {
                rootView.setBackgroundColor(Color.parseColor(hex))
                val c = WindowInsetsControllerCompat(window, window.decorView)
                c.isAppearanceLightStatusBars = !lightIcons
                c.isAppearanceLightNavigationBars = !lightIcons
            } catch (e: Exception) { }
        }
    }
    fun applyImmersive(on: Boolean) {
        runOnUiThread {
            val c = WindowInsetsControllerCompat(window, window.decorView)
            if (on) { c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE; c.hide(WindowInsetsCompat.Type.systemBars()) }
            else c.show(WindowInsetsCompat.Type.systemBars())
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        // Edge-to-edge: the app draws behind the status / navigation bars; padding keeps content clear of them.
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        rootView = FrameLayout(this)
        rootView.setBackgroundColor(Color.parseColor("#EAF0F8"))
        rootView.addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        setContentView(rootView)
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            WindowInsetsCompat.CONSUMED
        }

        // Serve assets over https://appassets.androidplatform.net so localStorage / IndexedDB keep a stable origin.
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
        }
        web.setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
                val path = r.url.path ?: ""
                if (path.startsWith("/__media/")) {
                    val key = Uri.decode(path.substring(9))
                    val uri = AuraMedia.uris[key]
                    if (uri != null) {
                        return try {
                            val mime = contentResolver.getType(uri) ?: "audio/mpeg"
                            val ins = contentResolver.openInputStream(uri)
                            WebResourceResponse(mime, null, 200, "OK", mapOf("Access-Control-Allow-Origin" to "*"), ins)
                        } catch (e: Exception) { WebResourceResponse("text/plain", "utf-8", 404, "Not found", mapOf(), java.io.ByteArrayInputStream(ByteArray(0))) }
                    }
                    return WebResourceResponse("text/plain", "utf-8", 404, "Not found", mapOf(), java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return loader.shouldInterceptRequest(r.url)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                filePathCb?.onReceiveValue(null)
                filePathCb = cb
                val types = p.acceptTypes.filter { it.isNotBlank() }
                val wantsAudio = types.any { it.startsWith("audio") }
                return try {
                    if (p.mode == 2) {
                        // Whole music folder: every song inside (and sub-folders) is added at once.
                        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), TREE_REQ)
                    } else if (wantsAudio) {
                        // Document picker: long-press or tick songs, then "Select all" to add many at once.
                        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                        i.addCategory(Intent.CATEGORY_OPENABLE)
                        i.type = "*/*"
                        i.putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*"))
                        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                        startActivityForResult(i, FILE_REQ)
                    } else {
                        startActivityForResult(p.createIntent(), FILE_REQ)
                    }
                    true
                } catch (e: Exception) {
                    filePathCb = null
                    false
                }
            }
        }
        bridge = AuraBridge(this, web)
        web.addJavascriptInterface(bridge!!, "Android")
        AuraMediaState.onAction = { a -> runOnUiThread { web.evaluateJavascript("window.auraNativeAction&&auraNativeAction('$a')", null) } }

        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        // Phone back button -> the player's own back handling (it calls Android.exitApp() at the root).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { web.evaluateJavascript("(typeof handleAuraBack==='function')?handleAuraBack():null", null) }
        })

        if (b == null) web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    fun startFolderForJs() {
        runOnUiThread {
            try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), TREE_JS_REQ) } catch (e: Exception) { }
        }
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(req, perms, res)
        if (req == 2) {
            val ok = res.isNotEmpty() && res[0] == PackageManager.PERMISSION_GRANTED
            web.evaluateJavascript("window.auraNativePermission&&auraNativePermission(" + ok + ")", null)
        }
    }

    private fun isAudioName(name: String): Boolean {
        val n = name.lowercase()
        return n.endsWith(".mp3") || n.endsWith(".m4a") || n.endsWith(".aac") || n.endsWith(".flac") ||
            n.endsWith(".wav") || n.endsWith(".ogg") || n.endsWith(".opus") || n.endsWith(".wma") || n.endsWith(".amr")
    }

    private fun collectAudio(tree: Uri): Array<Uri> {
        val out = ArrayList<Uri>()
        fun walk(docId: String, depth: Int) {
            if (depth > 8) return
            val kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val cols = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME
            )
            val c = contentResolver.query(kids, cols, null, null, null) ?: return
            val dirs = ArrayList<String>()
            try {
                while (c.moveToNext()) {
                    val id = c.getString(0) ?: continue
                    val mime = c.getString(1) ?: ""
                    val name = c.getString(2) ?: ""
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) dirs.add(id)
                    else if (mime.startsWith("audio/") || isAudioName(name)) out.add(DocumentsContract.buildDocumentUriUsingTree(tree, id))
                }
            } finally { c.close() }
            for (d in dirs) walk(d, depth + 1)
        }
        walk(DocumentsContract.getTreeDocumentId(tree), 0)
        return out.toTypedArray()
    }

    @Deprecated("file chooser result")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == FILE_REQ) {
            filePathCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data))
            filePathCb = null
        } else if (req == TREE_REQ) {
            val cb = filePathCb
            filePathCb = null
            val tree = if (res == RESULT_OK) data?.data else null
            if (cb == null) return
            if (tree == null) { cb.onReceiveValue(null); return }
            Thread {
                val list: Array<Uri> = try { collectAudio(tree) } catch (e: Exception) { emptyArray() }
                runOnUiThread { cb.onReceiveValue(list) }
            }.start()
        } else if (req == TREE_JS_REQ) {
            val tree = if (res == RESULT_OK) data?.data else null
            if (tree == null) return
            Thread {
                val arr = org.json.JSONArray()
                try {
                    var n = 0
                    for (u in collectAudio(tree)) {
                        var name = "song"; var size = 0L
                        try {
                            contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)?.use { c ->
                                if (c.moveToFirst()) { name = c.getString(0) ?: "song"; size = c.getLong(1) }
                            }
                        } catch (e: Exception) { }
                        n++
                        val key = "t" + System.currentTimeMillis() + "_" + n
                        AuraMedia.uris[key] = u
                        val o = org.json.JSONObject()
                        o.put("key", key); o.put("name", name); o.put("title", name.substringBeforeLast('.')); o.put("artist", ""); o.put("album", ""); o.put("dur", 0); o.put("size", size)
                        arr.put(o)
                    }
                } catch (e: Exception) { }
                val js = "window.auraNativeFolderPicked&&auraNativeFolderPicked(" + org.json.JSONObject.quote(arr.toString()) + ")"
                runOnUiThread { web.evaluateJavascript(js, null) }
            }.start()
        } else {
            super.onActivityResult(req, res, data)
        }
    }

    // Intentionally NO web.onPause(): it would stop the music when the screen locks.
    override fun onDestroy() {
        AuraMediaState.onAction = null
        AuraMediaState.playing = false
        AuraWidget.refresh(this)
        bridge?.release()
        super.onDestroy()
    }
}
