// AuraNative.kt — real lock-screen player for AuraPulse (WebView APK). NOT tested on a device.
// Package name: change to yours.
package com.aurapulse.app

import android.app.*
import android.content.*
import android.graphics.*
import android.os.*
import android.provider.Settings
import android.app.KeyguardManager
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import android.net.Uri
import androidx.core.app.ServiceCompat
import androidx.media.app.NotificationCompat.MediaStyle
import androidx.media.MediaBrowserServiceCompat
import androidx.media.AudioAttributesCompat
import androidx.media.AudioFocusRequestCompat
import androidx.media.AudioManagerCompat
import android.support.v4.media.MediaBrowserCompat
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.media.AudioManager
import android.widget.RemoteViews
import android.Manifest
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap

object AuraMediaState {
    var title = ""; var artist = ""; var album = ""; var art: Bitmap? = null
    var playing = false; var pos = 0L; var dur = 0L
    var onAction: ((String) -> Unit)? = null   // set by MainActivity -> evaluateJavascript
}

object AuraMedia {
    // key ("m123" / "t5") -> content Uri. The page streams songs from here via /__media/<key>
    val uris = ConcurrentHashMap<String, Uri>()
}

class AuraBridge(private val act: Activity, private val web: WebView) {
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            val ev: String = when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> "off"
                Intent.ACTION_SCREEN_ON -> "on"
                Intent.ACTION_USER_PRESENT -> "present"
                else -> ""
            }
            if (ev.isEmpty()) return
            act.runOnUiThread { web.evaluateJavascript("window.auraNativeScreen&&auraNativeScreen('" + ev + "')", null) }
        }
    }
    init {
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_SCREEN_ON)
        f.addAction(Intent.ACTION_USER_PRESENT)
        ContextCompat.registerReceiver(act, screenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
    }
    fun release() { try { act.unregisterReceiver(screenReceiver) } catch (e: Exception) { } }
    @JavascriptInterface fun openAppSettings() {
        val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + act.packageName))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        act.startActivity(i)
    }
    @JavascriptInterface fun updateMedia(t: String, a: String, al: String, artB64: String, playing: Boolean, posMs: Long, durMs: Long) {
        val s = AuraMediaState
        s.title = t; s.artist = a; s.album = al; s.playing = playing; s.pos = posMs; s.dur = durMs
        if (artB64.isNotEmpty()) try { val b = Base64.decode(artB64, Base64.DEFAULT); s.art = BitmapFactory.decodeByteArray(b, 0, b.size) } catch (_: Exception) {}
        val i = Intent(act, AuraMediaService::class.java)
        if (Build.VERSION.SDK_INT >= 26) act.startForegroundService(i) else act.startService(i)
    }
    @JavascriptInterface fun isLocked(): Boolean = (act.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).isKeyguardLocked
    @JavascriptInterface fun setShowOnLock(on: Boolean) = act.runOnUiThread {
        if (Build.VERSION.SDK_INT >= 27) { act.setShowWhenLocked(on); act.setTurnScreenOn(on) }
        else {
            val f = android.view.WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or android.view.WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            if (on) act.window.addFlags(f) else act.window.clearFlags(f)
        }
    }
    @JavascriptInterface fun requestUnlock() = act.runOnUiThread {
        if (Build.VERSION.SDK_INT >= 26) (act.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager).requestDismissKeyguard(act, null)
    }
    @JavascriptInterface fun openCast() = act.startActivity(Intent(Settings.ACTION_CAST_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    @JavascriptInterface fun openBluetoothSettings() = act.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    @JavascriptInterface fun openOutputSwitcher() = act.startActivity(Intent("android.settings.panel.action.MEDIA_OUTPUT").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    @JavascriptInterface fun exitApp() = act.finishAffinity()

    @JavascriptInterface fun setSystemBars(hex: String, lightIcons: Boolean) { (act as? MainActivity)?.applyBars(hex, lightIcons) }
    @JavascriptInterface fun setImmersive(on: Boolean) { (act as? MainActivity)?.applyImmersive(on) }

    private fun audioPerm(): String = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
    @JavascriptInterface fun hasAudioPermission(): Boolean = act.checkSelfPermission(audioPerm()) == PackageManager.PERMISSION_GRANTED
    @JavascriptInterface fun requestAudioPermission() = act.runOnUiThread { act.requestPermissions(arrayOf(audioPerm()), 2) }
    @JavascriptInterface fun listDeviceAudio(): String {
        val arr = JSONArray()
        try {
            val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            val cols = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM, MediaStore.Audio.Media.DURATION, MediaStore.Audio.Media.SIZE)
            val sel = MediaStore.Audio.Media.DURATION + " >= 20000 AND " + MediaStore.Audio.Media.IS_RINGTONE + " = 0 AND " +
                MediaStore.Audio.Media.IS_ALARM + " = 0 AND " + MediaStore.Audio.Media.IS_NOTIFICATION + " = 0"
            val c = act.contentResolver.query(base, cols, sel, null, MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")
            if (c != null) {
                try {
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val key = "m" + id
                        AuraMedia.uris[key] = ContentUris.withAppendedId(base, id)
                        val artist = c.getString(3) ?: ""
                        val o = JSONObject()
                        o.put("key", key); o.put("name", c.getString(1) ?: "")
                        o.put("title", c.getString(2) ?: (c.getString(1) ?: "Song"))
                        o.put("artist", if (artist == "<unknown>") "" else artist)
                        o.put("album", c.getString(4) ?: ""); o.put("dur", c.getLong(5)); o.put("size", c.getLong(6))
                        arr.put(o)
                    }
                } finally { c.close() }
            }
        } catch (e: Exception) { }
        return arr.toString()
    }
    @JavascriptInterface fun pickFolder() { (act as? MainActivity)?.startFolderForJs() }
    @JavascriptInterface fun shareText(t: String) = act.runOnUiThread {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t)
        act.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
    @JavascriptInterface fun getLocalIp(): String {
        try {
            val en = java.net.NetworkInterface.getNetworkInterfaces()
            while (en.hasMoreElements()) {
                val ni = en.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val ad = ni.inetAddresses
                while (ad.hasMoreElements()) {
                    val a = ad.nextElement()
                    if (a is java.net.Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress) return a.hostAddress ?: ""
                }
            }
        } catch (e: Exception) { }
        return ""
    }

}

class AuraMediaService : MediaBrowserServiceCompat() {
    private lateinit var session: MediaSessionCompat
    private val CH = "aura_media"
    private val h = Handler(Looper.getMainLooper())
    private var resumeAfterCall = false
    private var callHits = 0
    private var focusReq: AudioFocusRequestCompat? = null
    private var wasPlaying = false
    private var playStartedAt = 0L

    // Headphones unplugged / Bluetooth disconnected -> pause.
    private val noisy = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { if (AuraMediaState.playing) AuraMediaState.onAction?.invoke("pause") }
    }
    // Phone call / video call: pause, and resume when the call ends (no extra permission needed).
    private val callPoll = object : Runnable {
        override fun run() {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val m = am.mode
            val inCall = m == AudioManager.MODE_IN_CALL || m == AudioManager.MODE_RINGTONE
            callHits = if (inCall) callHits + 1 else 0
            if (callHits >= 2 && AuraMediaState.playing) { resumeAfterCall = true; AuraMediaState.onAction?.invoke("pause") }
            else if (!inCall && resumeAfterCall) { resumeAfterCall = false; AuraMediaState.onAction?.invoke("play") }
            h.postDelayed(this, 1000)
        }
    }
    private val focusListener = AudioManager.OnAudioFocusChangeListener { change ->
        when (change) {
            AudioManager.AUDIOFOCUS_LOSS -> {
                // The WebView may take focus itself when a song starts; ignore that moment.
                if (System.currentTimeMillis() - playStartedAt > 2500) AuraMediaState.onAction?.invoke("pause")
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                if (System.currentTimeMillis() - playStartedAt > 2500 && AuraMediaState.playing) { resumeAfterCall = true; AuraMediaState.onAction?.invoke("pause") }
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> AuraMediaState.onAction?.invoke("duck")
            AudioManager.AUDIOFOCUS_GAIN -> AuraMediaState.onAction?.invoke("unduck")
        }
    }
    private fun requestFocus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (focusReq == null) {
                focusReq = AudioFocusRequestCompat.Builder(AudioManagerCompat.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(AudioAttributesCompat.Builder().setUsage(AudioAttributesCompat.USAGE_MEDIA).setContentType(AudioAttributesCompat.CONTENT_TYPE_MUSIC).build())
                    .setOnAudioFocusChangeListener(focusListener).build()
            }
            AudioManagerCompat.requestAudioFocus(am, focusReq!!)
        } catch (e: Exception) { }
    }

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CH, "Music playback", NotificationManager.IMPORTANCE_LOW).apply { lockscreenVisibility = Notification.VISIBILITY_PUBLIC })
        session = MediaSessionCompat(this, "AuraPulse").apply {
            setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS or MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS)
            setCallback(object : MediaSessionCompat.Callback() {
                override fun onPlay() { AuraMediaState.onAction?.invoke("play") }
                override fun onPause() { AuraMediaState.onAction?.invoke("pause") }
                override fun onStop() { AuraMediaState.onAction?.invoke("pause") }
                override fun onSkipToNext() { AuraMediaState.onAction?.invoke("next") }
                override fun onSkipToPrevious() { AuraMediaState.onAction?.invoke("prev") }
                override fun onSeekTo(p: Long) { AuraMediaState.onAction?.invoke("seek:$p") }
                override fun onFastForward() { AuraMediaState.onAction?.invoke("seek:" + (AuraMediaState.pos + 10000)) }
                override fun onRewind() { AuraMediaState.onAction?.invoke("seek:" + maxOf(0L, AuraMediaState.pos - 10000)) }
            })
            isActive = true
        }
        sessionToken = session.sessionToken
        ContextCompat.registerReceiver(this, noisy, IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY), ContextCompat.RECEIVER_NOT_EXPORTED)
        h.postDelayed(callPoll, 1000)
    }
    // Android Auto / other media browsers: the car shows the Now Playing screen and its controls.
    override fun onGetRoot(clientPackageName: String, clientUid: Int, rootHints: Bundle?): BrowserRoot = BrowserRoot("aura_root", null)
    override fun onLoadChildren(parentId: String, result: Result<MutableList<MediaBrowserCompat.MediaItem>>) { result.sendResult(ArrayList()) }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) { "play","pause","next","prev" -> { AuraMediaState.onAction?.invoke(i.action!!) } }
        val s = AuraMediaState
        // NOTE: we deliberately do NOT request audio focus here. The WebView already manages focus for its own audio;
        // a second request made Android tell us 'focus lost' right after a new song started, which paused it.
        if (s.playing && !wasPlaying) { playStartedAt = System.currentTimeMillis() }
        wasPlaying = s.playing
        session.setMetadata(MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, s.title).putString(MediaMetadataCompat.METADATA_KEY_ARTIST, s.artist)
            .putString(MediaMetadataCompat.METADATA_KEY_ALBUM, s.album).putLong(MediaMetadataCompat.METADATA_KEY_DURATION, s.dur)
            .putBitmap(MediaMetadataCompat.METADATA_KEY_ALBUM_ART, s.art).build())
        session.setPlaybackState(PlaybackStateCompat.Builder()
            .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_SKIP_TO_NEXT or PlaybackStateCompat.ACTION_SKIP_TO_PREVIOUS or PlaybackStateCompat.ACTION_SEEK_TO or PlaybackStateCompat.ACTION_FAST_FORWARD or PlaybackStateCompat.ACTION_REWIND or PlaybackStateCompat.ACTION_STOP)
            .setState(if (s.playing) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED, s.pos, if (s.playing) 1f else 0f).build())
        fun pi(a: String, c: Int) = PendingIntent.getService(this, c, Intent(this, AuraMediaService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 0, packageManager.getLaunchIntentForPackage(packageName), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_media_play).setContentTitle(s.title).setContentText(s.artist).setSubText(s.album).setLargeIcon(s.art)
            .setContentIntent(open).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setOnlyAlertOnce(true).setOngoing(s.playing)
            .addAction(android.R.drawable.ic_media_previous, "Prev", pi("prev", 1))
            .addAction(if (s.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play, "Play/Pause", pi(if (s.playing) "pause" else "play", 2))
            .addAction(android.R.drawable.ic_media_next, "Next", pi("next", 3))
            .setStyle(MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1, 2)).build()
        ServiceCompat.startForeground(this, 77, n, if (Build.VERSION.SDK_INT >= 29) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK else 0)
        AuraWidget.refresh(this)
        return START_NOT_STICKY
    }
    override fun onDestroy() {
        h.removeCallbacks(callPoll)
        try { unregisterReceiver(noisy) } catch (e: Exception) { }
        try { focusReq?.let { AudioManagerCompat.abandonAudioFocusRequest(getSystemService(Context.AUDIO_SERVICE) as AudioManager, it) } } catch (e: Exception) { }
        session.release(); super.onDestroy()
    }
}

// Home-screen widget: cover, title, artist and Prev / Play-Pause / Next buttons.
class AuraWidget : AppWidgetProvider() {
    override fun onUpdate(c: Context, m: AppWidgetManager, ids: IntArray) { push(c, m, ids) }
    override fun onReceive(c: Context, i: Intent) {
        super.onReceive(c, i)
        val a = i.getStringExtra("aura_action")
        if (i.action == ACTION && a != null) AuraMediaState.onAction?.invoke(a)
    }
    companion object {
        const val ACTION = "com.aurapulse.app.WIDGET_ACTION"
        fun refresh(c: Context) {
            try {
                val m = AppWidgetManager.getInstance(c)
                val ids = m.getAppWidgetIds(ComponentName(c, AuraWidget::class.java))
                if (ids.isNotEmpty()) push(c, m, ids)
            } catch (e: Exception) { }
        }
        private fun push(c: Context, m: AppWidgetManager, ids: IntArray) {
            val s = AuraMediaState
            val alive = AuraMediaState.onAction != null && s.title.isNotEmpty()
            val v = RemoteViews(c.packageName, R.layout.aura_widget)
            v.setTextViewText(R.id.w_title, if (s.title.isEmpty()) "AuraPulse" else s.title)
            v.setTextViewText(R.id.w_artist, if (s.title.isEmpty()) "Tap to open your music" else s.artist)
            val art = s.art
            if (art != null) v.setImageViewBitmap(R.id.w_cover, art) else v.setImageViewResource(R.id.w_cover, R.mipmap.ic_launcher)
            v.setImageViewResource(R.id.w_play, if (s.playing) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play)
            val launch = PendingIntent.getActivity(c, 90, c.packageManager.getLaunchIntentForPackage(c.packageName), PendingIntent.FLAG_IMMUTABLE)
            fun act(code: Int, a: String): PendingIntent =
                if (!alive) launch else PendingIntent.getBroadcast(c, code, Intent(c, AuraWidget::class.java).setAction(ACTION).putExtra("aura_action", a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            v.setOnClickPendingIntent(R.id.w_root, launch)
            v.setOnClickPendingIntent(R.id.w_prev, act(91, "prev"))
            v.setOnClickPendingIntent(R.id.w_play, act(92, if (s.playing) "pause" else "play"))
            v.setOnClickPendingIntent(R.id.w_next, act(93, "next"))
            for (id in ids) m.updateAppWidget(id, v)
        }
    }
}

/* ===== MainActivity: add these lines =====
   webView.settings.javaScriptEnabled = true
   webView.settings.mediaPlaybackRequiresUserGesture = false
   webView.addJavascriptInterface(AuraBridge(this, webView), "Android")
   AuraMediaState.onAction = { a -> runOnUiThread { webView.evaluateJavascript("window.auraNativeAction&&auraNativeAction('$a')", null) } }
   if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
   // Do NOT call webView.onPause() in onPause()/onStop() — it stops audio when the screen locks.
   // Keep android:hardwareAccelerated="true" on <application>.

   ===== AndroidManifest.xml =====
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
   <uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PLAYBACK"/>
   <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
   <uses-permission android:name="android.permission.WAKE_LOCK"/>
   <service android:name=".AuraMediaService" android:exported="false" android:foregroundServiceType="mediaPlayback"/>
   (and on your <activity>: android:showWhenLocked="true" android:turnScreenOn="true" is optional; JS toggles it)

   ===== app/build.gradle =====
   implementation("androidx.media:media:1.7.0")
   implementation("androidx.core:core-ktx:1.13.1")
*/
